import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_cafeteria/main.dart';

void main() {
  testWidgets('Home screen shows cafeteria content', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const CampusCafeteriaApp());

    expect(find.text('CAMPUS CAFETERIA'), findsOneWidget);
    expect(find.text('View Menu'), findsOneWidget);
    expect(find.text('Campus Cafeteria'), findsWidgets);

    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Menu'), findsOneWidget);
    expect(find.text('Favorites'), findsOneWidget);
    expect(find.text('Categories'), findsOneWidget);
    expect(find.text('About'), findsOneWidget);
  });

  testWidgets('Bottom navigation switches between screens', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const CampusCafeteriaApp());

    expect(find.text('CAFETERIA MENU'), findsNothing);

    await tester.tap(find.text('Menu'));
    await tester.pumpAndSettle();

    expect(find.text('CAFETERIA MENU'), findsOneWidget);
  });

  testWidgets('Floating cart button opens empty cart screen', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const CampusCafeteriaApp());

    expect(find.byType(FloatingActionButton), findsOneWidget);
    expect(find.text('Your cart is empty.'), findsNothing);

    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();

    expect(find.text('MY CART'), findsOneWidget);
    expect(find.text('Your cart is empty.'), findsOneWidget);
  });
}
